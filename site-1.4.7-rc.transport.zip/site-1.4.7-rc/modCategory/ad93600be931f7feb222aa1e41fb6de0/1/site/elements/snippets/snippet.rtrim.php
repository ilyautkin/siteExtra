<?php
return rtrim($input, $options?:' ');